<?php
/*
Plugin Name: My Simple Plugin
Description: This is a simple plugin to demonstrate plugin creation in WordPress.
Version: 1.0
Author: Islam Bahaa
Author URI: https://www.example.com
License: GPL2
*/



function my_simple_plugin_footer_message() {
    echo '<p>This is a message from My Simple Plugin.</p>';
}
add_action('wp_footer', 'my_simple_plugin_footer_message');